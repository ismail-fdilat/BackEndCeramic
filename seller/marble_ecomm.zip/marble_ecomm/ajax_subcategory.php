<?php require_once("config.php");

$fetchsubcat=mysqli_query($conn,"select * from subcategory where cid= '".$_POST['cate_id']."'");
$row=mysqli_num_rows($fetchsubcat);

if($row > 0){
?>
<option value="">Select Sub Category</option>
               <?php while($fetchcat= mysqli_fetch_array($fetchsubcat))
					  {
						  ?>

  <option value="<?php echo $fetchcat['subid']?>"><?php echo $fetchcat['subname']?></option>
  <?php
}
}else{
	echo 0;
}
?>
