<?php
include('config.php');
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>forget password</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    
    <link href="upload/logo/5b31fee123fcadokan-sadara-logo.webp" rel="icon" type="image/x-icon">
    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
      <center></center>
        <a href="#">FORGET PASSWORD<b></b></a>

      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <form action="" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Email" name="email">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <!-- <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div> -->
          <!--<div class="form-group has-feedback">
            <select class="form-control"  name="usertype">
            <option value="">Select Usertype</option>
            <option value="1">Master Admin</option>
            <option value="2">Super Admin</option>
            <option value="3">Admin</option>
            <option value="4">User</option>

            </select>

          </div>-->
          <div class="row">
            <div class="col-xs-8">

            </div><!-- /.col -->
            
            <div class="col-xs-4">
              <button  type="submit" class="btn btn-primary btn-block btn-flat" name="submit">submit</button>
            </div><!-- /.col -->
          </div>
        </form>
<!--<a href="register.php" class="text-center">Create a new account</a> -->
        <!-- /.social-auth-links -->



      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
  </body>
</html>

<?php

if(isset($_POST['submit'])) 
{
  $email = $_POST['email'];
      $result=mysqli_query($conn,"SELECT * FROM seller WHERE semail='$email'");

      if(mysqli_num_rows($result)>0)
      {
         $row = mysqli_fetch_assoc($result);
         
         //$id=$_POST['id'];
         $encrypt_email= base64_encode($row['semail']);
                 $to = $email;
                 $subject = "bio-vadis ";
                 $message = '<b>Your password reset link.</b>';
                 
                 $message .= '<p>We recieved a password reset request. The link to reset your password is below</p>';
                 $message .= '<p><strong>Email:</strong>'.$email.'</p>';
                 $message .= '<p>Here is your password reset link:</p>'; 
                 $message .= '<p><a href="https://shrinkcom.com/organic_food/admin/resetpassword.php?ainfo='.$encrypt_email.' " target="_blank">Click here to reset your password</a> </p>';
                 $message .= '<p><strong>Thanks you <br> Bio-vadis </strong></p>';
                //echo $message; die;
                 $header = "From:shrinkcomekta@gmail.com \r\n";
                 $header .= "MIME-Version: 1.0\r\n";
                 $header .= "Content-type: text/html\r\n";
                 
                 $retval = mail ($to,$subject,$message,$header,'-fno-reply@ecocradle.in');
                
             ///mail($to, $subject, $message, "From: admin@gmail.com");
            
      }  
      else
      {
          echo '<div class="alert ">
  <strong>Invalid Email And Password</strong> 
</div>';
      }  
}

?>