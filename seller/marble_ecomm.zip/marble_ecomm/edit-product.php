<?php
	include('header.php');
	include('nav.php');
	include('resize.class.php');
$sqlFol1=mysqli_query($conn, "select * from category");
$sqlsize=mysqli_query($conn, "select * from size");
//insert product
	if(isset($_POST['submit']))
	{
	
	$sizes=($_POST['size']);
    $quan=($_POST['size_quan']);
	
	
		if(isset($_POST['chk']) && $_POST['chk']==1)
		{
			$cbox=$_POST['chk'];
		}
		else{
			$cbox=0;
		}
				if(empty($sizes)){
    $msg1='Please Choose Atleast One Size';
  }elseif(empty($quan)){
     $msg1='Please Enter Quantity';
  }
  else
  {
      
        if(!empty($_FILES['thumbnailimage']['name']))
  		{
		   
		    	$uploadimg = getimagesize($_FILES["thumbnailimage"]["tmp_name"]);
                 $width = $uploadimg[0];
                 $height = $uploadimg[1];	
		    if($width >= "150" && $height >= "50")
            { 
                  $path = "upload/product/";
                  $thumbimage = $path.time('his').basename($_FILES['thumbnailimage']['name']);
                  move_uploaded_file($_FILES['thumbnailimage']['tmp_name'],$thumbimage);
                  
            		$insertproduct = "update  `product` set `prod_title`='".$_POST['prod_title']."',`prod_title_ar`='".$_POST['prod_title_ar']."', `prod_price`='".$_POST['prod_price']."',
            		`prod_desc`='".$_POST['prod_desc']."'
            		,`prod_cate_id`='".$_POST['category_id']."',`prod_subcate_id`='".$_POST['sub_category_id']."',`stock`='".$cbox."', 
            	  `prod_subsubcate_id`='".$_POST['sub_sub_category_id']."',  
            	 `quantity`='".$_POST['prod_qty']."' , 
            		`offer_note`='".$_POST['prod_offer_note']."', `model_number`='".$_POST['model_number']."', brand_id = '".$_POST['brand_id']."',recomended_p='".$_POST['recomended']."',sale_price='".$_POST['sale_price']."',thumbnail_image='$thumbimage'";
            			$insertproduct.= "where prod_id='".$_GET['productid']."'";
        			
        	    $ab = array();
        			for($i=0;$i < count($quan);$i++)
              {
        				array_push($ab,$sizes[$i]);
        				//echo "select * from prod_size where prod_id = '".$_GET['productid']."' and size = '".$sizes[$i]."'";
        				$countSize = mysqli_query($conn,"select * from prod_size where prod_id = '".$_GET['productid']."' and size = '".$sizes[$i]."'");
        				if(mysqli_num_rows($countSize)>0)
                {
        					 $insert = mysqli_query($conn,"update prod_size set quantity = '$quan[$i]' where prod_id = ".$_GET['productid']." and size = '$sizes[$i]'");
        				}
        				else
                {
        					
        					 $insert = mysqli_query($conn,"INSERT INTO prod_size (size,quantity,prod_id) VALUES('$sizes[$i]','$quan[$i]','".$_GET['productid']."')");
        				}
                   
        		}
		$ab = implode(",", $ab);
		mysqli_query($conn,"delete from prod_size where prod_id = ".$_GET['productid']." and size NOT IN (".$ab.") ");
		
 	
			
			$insertproduct1=mysqli_query($conn, $insertproduct);
		  $quandata = mysqli_query($conn,"SELECT SUM(quantity) as quantity from prod_size Where prod_id='".$_GET['productid']."'");
        $data=mysqli_fetch_assoc($quandata);
        $totalquan=$data['quantity'];
       

          $updatequan = mysqli_query($conn,"UPDATE product set quantity='$totalquan' WHERE prod_id='".$_GET['productid']."'");	
  // File upload configuration
    $targetDir = "upload/product/";
    $allowTypes = array('jpg','png','jpeg','gif');

    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
        foreach($_FILES['files']['name'] as $key=>$val)
        {
		    	$uploadimg1 = getimagesize($_FILES["files"]["tmp_name"][$key]);
                $width1 = $uploadimg1[0];
                $height1 = $uploadimg1[1];	
		    if($width1 >= "200" && $height1 >= "200") 
            {
            
           // File upload path
            $_FILES['files']['name'][$key];
             $fileName = basename($_FILES['files']['name'][$key]);
            $targetFilePath = $targetDir . $fileName;
            $date=date('Y-m-d H:i:s');
            // Check whether file type is valid
           
                if(move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetFilePath)){
                    // Image db insert sql
                   
                  $insert = mysqli_query($conn,"INSERT INTO prod_image (image, uploaded_on,prod_id) VALUES('$fileName','$date','".$_GET['productid']."')");

      
                }
                else
                {
                   echo  $errorUpload .= $_FILES['files']['name'][$key];
                }
	   	  }
	   	  else
	   	  {
	   	      
	   	       $msg1="Image dimension should be  400X400";
	   	  }
           
		}
		if($insertproduct1){
			echo '<script>window.location.href="view-product.php?sucmsg=Product Updated successfully"</script>';
		}
		else{
			
			 $msg1="Product not Added";
		}		
        			
        			
        			
        			
        			
        			
        			
        			
            }
            else
            {
                 $msg1="Thumbnail Image dimension should be 350X350";
            }
		}
		else
		{
		     
		     $insertproduct = "update  `product` set `prod_title`='".$_POST['prod_title']."',`prod_title_ar`='".$_POST['prod_title_ar']."', `prod_price`='".$_POST['prod_price']."',
        		`prod_desc`='".$_POST['prod_desc']."',`prod_desc_ar`='".$_POST['prod_desc_ar']."'
        		,`prod_cate_id`='".$_POST['category_id']."',`prod_subcate_id`='".$_POST['sub_category_id']."',`stock`='".$cbox."', 
        	  `prod_subsubcate_id`='".$_POST['sub_sub_category_id']."',  
        	 `quantity`='".$_POST['prod_qty']."' , 
        		`offer_note`='".$_POST['prod_offer_note']."', `model_number`='".$_POST['model_number']."', brand_id = '".$_POST['brand_id']."',recomended_p='".$_POST['recomended']."',sale_price='".$_POST['sale_price']."'";
        			$insertproduct.= "where prod_id='".$_GET['productid']."'";
        			
        			$ab = array();
			for($i=0;$i < count($quan);$i++){
				array_push($ab,$sizes[$i]);
				//echo "select * from prod_size where prod_id = '".$_GET['productid']."' and size = '".$sizes[$i]."'";
				$countSize = mysqli_query($conn,"select * from prod_size where prod_id = '".$_GET['productid']."' and size = '".$sizes[$i]."'");
				if(mysqli_num_rows($countSize)>0){
					 $insert = mysqli_query($conn,"update prod_size set quantity = '$quan[$i]' where prod_id = ".$_GET['productid']." and size = '$sizes[$i]'");
				}
				else{
					
					 $insert = mysqli_query($conn,"INSERT INTO prod_size (size,quantity,prod_id) VALUES('$sizes[$i]','$quan[$i]','".$_GET['productid']."')");
				}
           
		}
		$ab = implode(",", $ab);
		mysqli_query($conn,"delete from prod_size where prod_id = ".$_GET['productid']." and size NOT IN (".$ab.") ");
		
 	
			
			
		  $quandata = mysqli_query($conn,"SELECT SUM(quantity) as quantity from prod_size Where prod_id='".$_GET['productid']."'");
        $data=mysqli_fetch_assoc($quandata);
        $totalquan=$data['quantity'];
       

          $updatequan = mysqli_query($conn,"UPDATE product set quantity='$totalquan' WHERE prod_id='".$_GET['productid']."'");	
  // File upload configuration
    $targetDir = "upload/product/";
    $allowTypes = array('jpg','png','jpeg','gif');

    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = '';
	if(!empty($_FILES['files']['name'][0])){
		$io = 1;
		foreach($_FILES['files']['name'] as $key=>$val)
        {
					//	var_dump($_FILES['files']); 
		    	$uploadimg1 = getimagesize($_FILES["files"]["tmp_name"][$key]);
				
				
                 $width1 = $uploadimg1[0];
                 $height1 = $uploadimg1[1];	
				
		    if($width1 >= "200" && $height1 >= "200") 
            {
			
           // File upload path
        
             $fileName = time('his').basename($_FILES['files']['name'][$key]);
            $targetFilePath = $targetDir.$fileName;
            $date=date('Y-m-d H:i:s');
            // Check whether file type is valid
             move_uploaded_file($_FILES['files']['tmp_name'][$key],$targetFilePath);

                // if(move_uploaded_file($_FILES["files"]["tmp_name"][$key],$targetFilePath))
                // {
                    // Image db insert sql
                  
                  $insert = mysqli_query($conn,"INSERT INTO `prod_image` (`image`,`uploaded_on`,`prod_id`) VALUES('$fileName','$date','".$_GET['productid']."')");

                    // if($io == 1)
                    // {
                    //   $insertproduct1=mysqli_query($conn, $insertproduct);
                    // }

                // }
                // else
                // {
                //    echo  $errorUpload .= $_FILES['files']['name'][$key];
                // }
				
				
	   	  }
	   	  else
	   	  {
	   	       $msg1="Image dimension should be  400X400";
	   	  }
	   	
			$io++;
           
		}
		
	}
	else
  {
		$insertproduct1=mysqli_query($conn,$insertproduct);
	}
        
		if(!isset($msg1)){
			echo '<script>window.location.href="view-product.php?sucmsg=Product Updated successfully"</script>';
		}
		else{
			
			 $msg1="Image dimension should be 400X400";
		}
		
		}
	  
	}
  
	}
	
	if(isset($_POST['uploadproduct'])){
		
		
		foreach($_POST['productimage'] as $imgid){
			
			mysqli_query($conn,"update prod_image set prod_id = '".$_GET['productid']."' where id = '$imgid'");
			
		}
	}
	
	if(isset($_POST['uploadthumbnail'])){
		
		
		
			
			$thumbimagesql = mysqli_query($conn,"select image from prod_image where id = '".$_POST['thumbimage']."' ");
			$fetchThumb = mysqli_fetch_assoc($thumbimagesql);
			mysqli_query($conn,"update product set thumbnail_image = '".$fetchThumb['image']."' where prod_id = '".$_GET['productid']."'");
			
			mysqli_query($conn,"delete from prod_image where id = '".$_POST['thumbimage']."' ");
			
		
	}
	
	
	
	
//get brand details
$sqlFol11=mysqli_query($conn, "select * from product where prod_id='".$_GET['productid']."'");

$row1=mysqli_fetch_assoc($sqlFol11);	



//get sub category
$sqlFol13=mysqli_query($conn, "select * from subcategory where cid='".$row1['prod_cate_id']."'");


//get sub sub category
// $sqlFol14=mysqli_query($conn, "select * from sub_subcategory where sub_subcate_id='".$row1['prod_subsubcate_id']."'");

// $row4=mysqli_fetch_assoc($sqlFol14);	
//get brand
// $sqlFol15=mysqli_query($conn, "select * from brand where brand_id='".$row1['brand_id']."'");

// $row5=mysqli_fetch_assoc($sqlFol15);
?>		
<style>

    
    
     #errmsg
{
color: red;
}
  #errmsg1
{
color: red;
}

.has-error_phone .form-control {
    border-color: #a94442;
    -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
    box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
}




/* =========================== checkbox style ==========================*/

/* The container */
.checkbox_container {
  display: inline-block;
  position: relative;
  padding-left: 35px;
  margin-bottom: 12px;
  cursor: pointer;
  font-size: 15px;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* Hide the browser's default checkbox */
.checkbox_container input {
  position: absolute;
  opacity: 0;
  cursor: pointer;
  height: 0;
  width: 0;
}

/* Create a custom checkbox */
.checkbox_checkmark {
  position: absolute;
  top: 0;
  left: 0;
  height: 25px;
  width: 25px;    
  border: 2px solid #333;
}

/* On mouse-over, add a grey background color */
/*.checkbox_container:hover input ~ .checkbox_checkmark {*/
/*  background-color: #ccc;*/
/*}*/

/* When the checkbox is checked, add a blue background */
/*.checkbox_container input:checked ~ .checkbox_checkmark {*/
/*  background-color: #2196F3;*/
/*}*/

/* Create the checkmark/indicator (hidden when not checked) */
.checkbox_checkmark:after {
  content: "";
  position: absolute;
  display: none;
}

/* Show the checkmark when checked */
.checkbox_container input:checked ~ .checkbox_checkmark:after {
  display: block;
}

/* Style the checkmark/indicator */
.checkbox_container .checkbox_checkmark:after {
  left: 9px;
  top: 5px;
  width: 5px;
  height: 10px;
  border: solid #333;
  border-width: 0 3px 3px 0;
  -webkit-transform: rotate(45deg);
  -ms-transform: rotate(45deg);
  transform: rotate(45deg);
}

/*=========================== form control =============================*/

.form_control {
  display: block;
  width: 100%;
  height: 34px;
  padding: 6px 12px;
  font-size: 14px;
  line-height: 1.42857143;
  color: #555;
  background-color: #fff;
  background-image: none;
  border: 1px solid #ccc;
  border-radius: 4px;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
  -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
       -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
          transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
}

.form_control:focus {
  border-color: #000;
  outline: 0;
  -webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(0, 0, 0, .6);
          box-shadow: inset 0 1px 1px rgba(0,0,0,.075), 0 0 8px rgba(0, 0, 0, .6);
}
/*====================== row col ==================*/
/*.m_row{}*/
/*col_md_4*/
.m_row:before,
.m_row:after{
  display: table;
  content: " ";
}

.m_row:after{
  clear: both;
}
.col_md_4{
  position: relative;
  min-height: 1px;
  padding-right: 15px;
  padding-left: 15px;
  float: left;
}
.col_md_12{
  position: relative;
  min-height: 1px;
  padding-right: 15px;
  padding-left: 15px;
  float: left;
}
@media (min-width: 992px) {
    
  .col_md_4 {
    width: 33.33333333%;
  }
    .col_md_12 {
    width: 100%;
  }
}



</style>


<form role="form" method="post" action="" enctype="multipart/form-data">
  <div class="content-wrapper"> 
    <!-- Content Header (Page header) --> 
    
    <!-- Main content -->
    <section class="content">
      <div class="row"> 
        
        <!-- left column -->
        <div class="col-md-12"> 
		<div class="col-md-2"></div>
		 <div class="col-md-8 "> 
          <!-- general form elements -->
         	 <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Product</h3>
            </div>
            <!-- /.box-header --> 
            <!-- form start -->
            
            <div class="box-body">
              <?php if(isset($msg1))
				{
					?>
              <p style="color:#e74c3c; font-weight:bold" align="center"><i class="fa fa-times"></i> <?php echo $msg1;


					?>
              <?php
                }
				if(isset($msg))
				{
					?>
              <p style="color:#2ecc71; font-weight:bold" align="center"><i class="fa fa-check"></i> <?php echo $msg;?></p>
              <?php
				}
               ?>
              <div class="form-group">
                <label for="exampleInputEmail1">Product Category</label>
                <select onchange="subcategoryget(this.value),brandget(this.value),sizeget(this.value)" class="form-control prod_cat" id="exampleInputEmail1 " placeholder="Enter Product Title" name="category_id" required>
                          
                  <?php    while($rowS= mysqli_fetch_assoc($sqlFol1)) 

					  {
						  ?>
                             <option <?php if($row1['prod_cate_id'] == $rowS['cid']){ echo "selected"; } ?> value="<?php echo $rowS['cid']; ?>"><?php echo $rowS['cname']; ?></option>
                  <?php
					  }
					  ?>
                </select>
              </div>
              <?php if($row1['prod_subcate_id'] != ''){ ?>
              <div class="form-group">
                <label for="exampleInputEmail1">Product Sub Category</label>
                <select class="form-control" id="subcategory" placeholder="Enter Product Title" name="sub_category_id"  onchange="subcategoryget1(this.value),sizeget1(this.value)" required>
				<?php while($row3=mysqli_fetch_assoc($sqlFol13)){ ?>
                                                  <option <?php if($row1['prod_subcate_id'] == $row3['subid']){ echo "selected"; }?> value="<?php echo $row3['subid']; ?>"><?php echo $row3['subname']; ?></option>
				<?php } ?>

                </select>
              </div>
			  
<!-- 
                <div class="form-group">
                <label for="exampleInputEmail1">Brand</label>
                <select class="form-control" id="brand" placeholder="Enter Product Title" name="brand_id"   required>
				<?php $fetchsubcat=mysqli_query($conn,"select * from assign_brand where subcategory_id = '".$row1['prod_subcate_id']."' ");
				$rowSize= mysqli_fetch_assoc($fetchsubcat);
				$brand_ids=$rowSize['brand_id'];
				$ids=explode(',', $brand_ids);							
				foreach ($ids as $key => $id) {
					  	 $sqlFol4=mysqli_query($conn, "select * from  brand where brand_id ='$id'");
                             $ro4= mysqli_fetch_assoc($sqlFol4);
					  
						  ?>

					<option value="<?php echo $ro4['brand_id']?>" <?php if($ro4['brand_id'] == $row1['brand_id']){ echo "selected";  } ?> ><?php echo $ro4['brand_title']?></option>
				<?php } ?>
                    
                </select>
              </div>
               
			<?php }else{ ?>
				 <div class="form-group">
                <label for="exampleInputEmail1">Brand</label>
                <select class="form-control" id="brand" placeholder="Enter Product Title" name="brand_id"   required>
				<?php $fetchsubcat=mysqli_query($conn,"select * from assign_brand where category_id = '".$row1['prod_cate_id']."' ");
				$rowSize= mysqli_fetch_assoc($fetchsubcat);
				$brand_ids=$rowSize['brand_id'];
				$ids=explode(',', $brand_ids);							
				foreach ($ids as $key => $id) {
					  	 $sqlFol4=mysqli_query($conn, "select * from  brand where brand_id ='$id'");
                             $ro4= mysqli_fetch_assoc($sqlFol4);
					  
						  ?>

					<option value="<?php echo $ro4['brand_id']?>"><?php echo $ro4['brand_title']?></option>
				<?php } ?>
                    
                </select>
              </div>
		<?php	} ?>

 -->               <div class="form-group m_row">
            
                <label for="exampleInputEmail1">Sizes :-</label>
                  <div id="size">
					<?php 
$fetchsubcat=mysqli_query($conn,"select * from assign_size where category_id= '".$row1['prod_cate_id']."' AND subcategory_id = '".$row1['prod_subcate_id']."'");

$rowSize= mysqli_fetch_assoc($fetchsubcat);
$size_ids=$rowSize['size_id'];
$ids=explode(',', $size_ids);
  foreach ($ids as $key => $id) {

      $sqlFol4=mysqli_query($conn, "select * from  size where size_id ='$id'");
      $ro4= mysqli_fetch_assoc($sqlFol4);
	  $prodQua = mysqli_query($conn,"select * from prod_size where size = '$id' and prod_id = '".$_GET['productid']."'");
	 $prodQuaCount = mysqli_num_rows($prodQua);
	 $fetchQuan = mysqli_fetch_assoc($prodQua); ?>
        <div class="col_md_4">   
        <div class="m_row">
            <div class="col_md_12">
                <label class="checkbox_container">
  <input style="width:20px;" type="checkbox" <?php if($prodQuaCount>0){ echo "checked"; }?> class="checksize" name="size[]" value="<?php echo $ro4['size_id'];?>" id="<?php echo $ro4['size_id'];?>" style="margin-left: 5px; margin-right: 5px;">
                    <span class="checkbox_checkmark"></span>
                    <?php echo $ro4['name'];?>
                </label>
          
          </div>
          <div class="col_md_12">
            <span  id="hide_<?php echo $ro4['size_id'];?>"><?php  if($prodQuaCount>0){ ?>
			<input placeholder="Quantity" class="form_control" name="size_quan[]" type="number[]" id="input_<?php echo $ro4['size_id'];?>" value="<?php echo $fetchQuan['quantity'] - $fetchQuan['sold_qty']; ?>">
			<?php }?> </span>
          </div>
          </div>
      </div>  
 <script>
  $( document ).ready(function() {
   
     $("#<?php echo $ro4['size_id'];?>").click(function() {
         
      if($(this).is(":checked")) {
          $.ajax({  
                          url:"getSizeCheckQty.php",  
                          method:"POST",  
                           data:{productid:<?php echo $_GET['productid']; ?>,size:$(this).val()},
                          success:function(data)  
                          {  
                                 $("#hide_<?php echo $ro4['size_id'];?>").append('<input placeholder="Quantity" class="form_control" name="size_quan[]" type="number[]" id="input_<?php echo $ro4['size_id'];?>" value="'+data.trim()+'" >');
                          }
                     });

        

      } else {

          $("#input_<?php echo $ro4['size_id'];?>").remove();
      }
  });
});
 </script>
<?php }
?>
					
					
					
				  </div>




              </div>
              
              <div class="form-group">
                <label for="exampleInputEmail1">Product Title</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Product Title" name="prod_title" value="<?php echo $row1['prod_title'];?>" required>
              </div>
			  
			      
              <div class="form-group">
                <label for="exampleInputEmail1">Product Description</label>
                <textarea class="form-control" id="pdetails1" placeholder="" name="prod_desc" required value=""><?php echo $row1['prod_desc'];?></textarea>
              </div>
			  
			    
              <div class="form-group">
                <label for="exampleInputEmail1">Product Price</label>
                <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Enter Price" name="prod_price" value="<?php echo $row1['prod_price'];?>" required>
              </div>
              
               <div class="form-group">
                <label for="exampleInputEmail1">Sale Price</label>
                <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Enter Product sale price" name="sale_price" required value="<?php echo $row1['sale_price'];?>">
              </div>
              
              
              	<div class="form-group">
                <label for="exampleInputEmail1">Model Number</label>
                <input type="text" id="datepicker" class="form-control" name="model_number" value="<?php echo $row1['model_number'];?>">
              </div> 
          <div class="form-group">
                <label for="exampleInputEmail1">Product Quantity</label>
                <input type="text" class="form-control" name="prod_qty" ng-model="prod_qty" value="<?php echo $row1['quantity'];?>">
              </div> 
                                   
                 <div class="form-group">
                <label for="exampleInputEmail1">Product Offer Note</label>
               <textarea class="form-control" rows="5" placeholder="Enter Offer Note"  style="height:70px;" name="prod_offer_note" ng-model="offer_note" value="<? echo $row1['offer_note'];?>"><?php echo $row1['offer_note'];?></textarea>
              </div>      

			<!-- <div class="form-group">
                <label for="exampleInputEmail1">Product Offer Note (Arabic)</label>
               <textarea class="form-control" rows="5" placeholder="Enter Offer Note"  style="height:70px;" name="prod_offer_note_ar" ng-model="offer_note"><?php echo $row1['offer_note_ar'];?></textarea>
              </div>  			  
			 -->        
           <!--<div class="form-group">-->
           <!--     <label for="exampleInputEmail1">Product Quantity Per In ML</label>-->
           <!--              <select class="form-control" id="regions"  name="qty_in_ml" >-->
           <!--                             <option value="<? echo $row1['qty_in_ml'];?>" ><? echo $row1['qty_in_ml'];?> </option>-->
           <!--                             <option value="187.5 ML">187.5 ML</option>-->
           <!--                             <option value="375 ML" >375 ML</option>-->
           <!--                             <option value="500 ML">500 ML</option>-->
           <!--                              <option value="750 ML" >750 ML</option>-->
           <!--                             <option value="1L">1 L</option>-->
           <!--                             <option value="1.5 L">1.5 L</option>-->
           <!--                             <option value="3 L" >3 L</option>-->
           <!--                             <option value="4.5 L">4.5 L</option>-->
           <!--                              <option value="6 L" >6 L</option>-->
           <!--                             <option value="9 L">9 L</option>-->
           <!--                              <option value="12 L" >12 L</option>-->
           <!--                             <option value="20 L">20 L</option>-->
           <!--                         </select>-->
           <!--   </div> -->
			 
			   <div class="form-group m_row">
			     <label for="exampleInputEmail1" style="display:block;">Product Images</label>
             <?php 
			 $getimage = mysqli_query($conn,"select * from prod_image where prod_id = '".$_GET['productid']."'");
			 while($rimg = mysqli_fetch_assoc($getimage)){ ?>
                <div class="col-md-2">

<img src="upload/product/<?= $rimg['image'];?>"width="100px" height="100px" id="img<?php echo $rimg['id'];?>"> 


</br>

<!--       <label for="s_image<?php echo $rimg['id'];?>" class="btn-info" style="padding: 4px; width: 22px; height: 23px;" >
      <i class="fa fa-pencil" aria-hidden="true"></i>
        <input type="file" id="s_image<?php echo $rimg['id'];?>" onchange="image_change(<?php echo $rimg['id'];?>,<?php echo $_GET['productid'];?>)" name="s_image" style="display:none;" value="<?php echo $rimg['image'];?>">
                                                     
      </label> -->

<a href="delete_img_product.php?d_id=<?php echo $rimg['id'];?>&p_id=<?php echo $_GET['productid'];?>" class="btn-info glyphicon glyphicon-trash" style="color: red; padding:5px;"></a>
</div>
			 <?php } ?>
              </div>
              
              <div class="form-group m_row">
              
                <label for="exampleInputEmail1">Product Image <span style="color:red;font-size:12px">(Image should be 400X400)</span></label>
                <input type="file" name="files[]"  multiple > 
				<br>
				
              </div>
			  
			  <div class="form-group m_row">
              
                <label for="exampleInputEmail1">Product Bulk Images <span style="color:red;font-size:12px">(Image should be 400X400)</span></label>
               
				<br>
				 <button type="button" class="btn btn-info" data-toggle="modal" data-target="#openPro">Select Bulk images</button>
              </div>
              
              
              <div class="form-group m_row">
                <label for="exampleInputEmail1">Thumbnail Image<span style="color:red;font-size:12px">(Image should be  350X350)</span></label>
                <input type="file" name="thumbnailimage" accept="image/jpg,image/png,image/jpeg,image/gif">
              </div>
			  
			   <div class="form-group m_row">
                <label for="exampleInputEmail1">Select Thumbnail Image<span style="color:red;font-size:12px">(Image should be  350X350)</span></label>
				<br>
				 <button type="button" class="btn btn-info" data-toggle="modal" data-target="#openThumb">Select image</button>
               
              </div>
              <img src="<?= $row1['thumbnail_image'];?>"width="100px" height="100px" >
              
              <div class="form-group">
                <!--<label for="exampleInputEmail1">Mark as Recomended </label>-->
                <input type="checkbox" name="recomended" value=1 <?php if($row1['recomended_p']==1){echo "checked";}?>>Mark as Recomended
              </div> 
           
              <div class="box-footer">
                <button type="submit" class="btn btn-success" name="submit">Add</button>
              </div>
            </div>
            <!-- /.box-body --> 
            
          </div>
		  
		  </div>
		  </form>
	 <!-- Modal -->
  <div class="modal fade" id="openPro" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Select Images</h4>
        </div>
		<form action="" method="post">
        <div class="modal-body">
          <?php 
				$query = mysqli_query($conn,"select * from prod_image where is_image = 'pro' and prod_id = 0");
				while($rowimages = mysqli_fetch_assoc($query)){ ?>
				<div class="col-md-3">
					<img class="img-thumbnail" src="upload/product/<?php echo $rowimages['image'];?>">
					<input type="checkbox" name="productimage[]" value="<?php echo $rowimages['id'];?>">
					<label> Select Image</label>
			   </div>
			<?php } ?>

            
           
           <div class="col-md-12 text-center" style="margin-top:50px;">
           	<input type="submit" name="uploadproduct" class="btn btn-primary" value='Upload'>
           </div>
        </div>
		</form>
        <div class="modal-footer">
         
        </div>
      </div>
      
    </div>
  </div>	 
  
  	 <!-- Modal -->
  <div class="modal fade" id="openThumb" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Select Thumbnail Image</h4>
        </div>
		<form action="" method="post">
        <div class="modal-body">
          <?php 
				$query = mysqli_query($conn,"select * from prod_image where is_image = 'thumb' and prod_id = 0");
				while($rowimages = mysqli_fetch_assoc($query)){ ?>
				<div class="col-md-3">
					<img class="img-thumbnail" src="<?php echo $rowimages['image'];?>">
					<input type="radio" name="thumbimage" value="<?php echo $rowimages['id'];?>">
					<label> Select Image</label>
			   </div>
			<?php } ?>

            
           
           <div class="col-md-12 text-center" style="margin-top:50px;">
           	<input type="submit" name="uploadthumbnail" class="btn btn-primary" value='Upload'>
           </div>
        </div>
		</form>
        <div class="modal-footer">
         
        </div>
      </div>
      
    </div>
  </div>
<!--  <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>--> 
<!-- Bootstrap 3.3.5 --> 
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
 

  <script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
  
  <script>
function subcategoryget(str){
	//alert('hi');
	$.post("ajax_subcategory.php", {cate_id:str}, function(result){
 
      if(result != 0){
         $("#subcat_div").show();
         $("#subcategory").prop('required',true);
        $("#subcategory").html(result);


      }else{
        $("#subcategory").prop('required',false);
         $("#subcat_div").hide();
      }
    });
}

function brandget(str){
  //alert('hi');
  $.post("ajax_brand.php", {cate_id:str}, function(result){
        $("#brand").html(result);
    });
}

function sizeget(str){
  //alert('hi');
  $.post("ajax_size.php", {cate_id:str}, function(result){
        $("#size").html(result);
    });
}
function sizeget1(str){
  //alert('hi');
  var cat=$(".prod_cat").val();

  $.post("ajax_size1.php", {cate_id:str,cat:cat}, function(result){
        $("#size").html(result);
    });
}
</script>

<script>
function subcategoryget1(str){
	//alert(str);
   var cat=$(".prod_cat").val();

	$.post("ajax_subcategory1.php", {cate_id:str,cat:cat}, function(result){
        $("#brand").html(result);
    });
}


</script>

<script>
function brand(str){
	//alert(str);
	$.post("ajax_brand.php", {cate_id:str}, function(result){
        $("#brandid").html(result);
    });
}
</script>
  
  
  
  <script>
  $( function() {
     $('#datepicker').datepicker( {
            yearRange: '1950:2019',
            changeMonth: true,
            changeYear: true,
            showButtonPanel: true,
            dateFormat: 'MM yy',

            onClose: function(dateText, inst) { 
                $(this).datepicker('setDate', new Date(inst.selectedYear, inst.selectedMonth, 1));
            }
    });
  } );
  </script>
    <script>
        
function image_change(id,menuId) {

    var name = document.getElementById("s_image"+id).files[0].name;
// console.log(name);
  var form_data = new FormData();

  var ext = name.split('.').pop().toLowerCase();
  // console.log(ext);
  if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
  {
   alert("Invalid Image File");
  }

  var oFReader = new FileReader();

  oFReader.readAsDataURL(document.getElementById("s_image"+id).files[0]);
  var f = document.getElementById("s_image"+id).files[0];
  var fsize = f.size||f.fileSize;
  if(fsize > 2000000)
  {
   alert("Image File Size is very big");
  }
  else
  {
   form_data.append("s_image"+id, document.getElementById('s_image'+id).files[0]);
   form_data.append("id",id);
   form_data.append("pid",menuId);
   $.ajax({
    url:"productImage.php",
    method:"POST",
    data: form_data,
    contentType: false,
    cache: false,
    processData: false,
    beforeSend:function(){
    // $('#uploaded_image').html("<label class='text-success'>Image Uploading...</label>");
    },   
    success:function(data)
    {
		$('#img'+id).attr("src",data);
     //$('#uploaded_image').html(data);

    }
   });
  }

}
</script>
<?php
include('footer.php');
?>
