<?php
include('config.php');

if(isset($_POST['submit']))
{
	$user=$_POST['userid'];
	$pass=$_POST['password'];
	//$usertype=$_POST['usertype'];

if(empty($user))
	{
		$msg1="Please enter your email";
	}

	elseif(empty($pass))
	{
		$msg1="Please Enter Password";
	}

	else
	{
		$statement =mysqli_query($conn,"select * from seller where semail ='".$user."' and spass ='".md5($pass)."'");
	
		//print_r("select * from tbl_admin where email ='".$user."' and password ='".md5($pass)."'"); die;
		$num_admin = mysqli_num_rows($statement);
        $row_admin = mysqli_fetch_assoc($statement);
		if($num_admin>0)
		{
			
			$_SESSION['seller_id']=$row_admin['seller_id'];
			$_SESSION['sname']=$row_admin['sname'];
	
			$_SESSION['semail']=$row_admin['semail'];
			$_SESSION['phone']=$row_admin['phone'];
			
			echo '<script>'."window.location.href = 'dashboard.php'".'</script>';
			
		}
		else
		{
			$msg1="Username and password do not exist";
		}
	}
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Log in</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
    
    <link href="upload/logo/5b31fee123fcadokan-sadara-logo.webp" rel="icon" type="image/x-icon">
    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="hold-transition login-page">
    <div class="login-box">
      <div class="login-logo">
      <center></center>
        <a href="#"><b>Seller Login</b></a>

      </div><!-- /.login-logo -->
      <div class="login-box-body">
        <p class="login-box-msg">Sign in to start</p>
         <?php if(isset($msg1))
				{
					?>
				<p class="text-danger" align="center"><i class="fa fa-times"></i> <?php echo $msg1;?></p>
				<?php
                }
               ?>
        <form action="" method="post">
          <div class="form-group has-feedback">
            <input type="text" class="form-control" placeholder="Email" name="userid">
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
            	<a href="forgetpassword.php"> Forgot password?</a>
          </div>
          <!--<div class="form-group has-feedback">
            <select class="form-control"  name="usertype">
            <option value="">Select Usertype</option>
            <option value="1">Master Admin</option>
            <option value="2">Super Admin</option>
            <option value="3">Admin</option>
            <option value="4">User</option>

            </select>

          </div>-->
          <div class="row">
            <div class="col-xs-8">

            </div><!-- /.col -->
            <div  align="center" >
              <button type="submit" class="btn btn-primary btn-block btn-flat" name="submit">Sign In</button>
              <a href="createseller.php">create account  as seller </a>
            </div><!-- /.col -->
          </div>
        </form>
<!--<a href="register.php" class="text-center">Create a new account</a> -->
        <!-- /.social-auth-links -->



      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="plugins/iCheck/icheck.min.js"></script>
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>
  </body>
</html>
