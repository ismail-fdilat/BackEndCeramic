<?php
include('header.php');
include('nav.php');



  $sqlFol1=mysqli_query($conn,"select * from book_order where confirm_status=1 order by id desc  LIMIT 5 ");
  $nS=mysqli_num_rows($sqlFol1);
  
    $sqlFolfull=mysqli_query($conn,"select * from book_order where confirm_status=1 ");
  $nSfull=mysqli_num_rows($sqlFolfull);

    $sqlFol2=mysqli_query($conn,"select * from users");
  $nS2=mysqli_num_rows($sqlFol2);

    
    $sqlFol4=mysqli_query($conn,"select * from product");
  $nS4=mysqli_num_rows($sqlFol4);


?>
<style>
.btn-change{
    background-color: #605ca8;
    border-color: #605ca8;
    color:white;
}
.btn-change:hover {
   background-color: #605ca8;
    border-color: #605ca8;
    color:white;
}
    .label-pending
{
background-color: #f39c12;
}
.table_body{
    background:#fff;
    padding:10px;
    margin-top:80px;
}
.bg_dark_tb{
    background: #333;
    color: #fff;
}
.table_body .table>thead>tr>th, .table_body .table>tbody>tr>th, .table_body .table>tfoot>tr>th, .table_body .table>thead>tr>td, .table_body .table>tbody>tr>td, .table_body .table>tfoot>tr>td{
        padding: 16px 10px;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Dashboard

          </h1>
       <?php

                  if(isset($sucmsg))
          {
          ?>
                  <center><h4 class="box-title" style="color:green;"><i class="fa fa-check"></i> <?php echo $sucmsg;  ?> </h4></center>
                  <?php
          }
          if(isset($errmsg))
          {
            ?>
                      <center><h4 class="box-title" style="color:red"><i class="fa fa-times"></i> <?php echo $errmsg;  ?> </h4></center>
                      <?php
          }
          ?>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Info boxes -->
          <div class="row">
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
         <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo $nS2;?></h3>
                  <p>User(s)</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="view-user.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
        </div>
            <!-- ./col -->
            <?php /*?><div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3><?php echo '0';?></h3>
                  <p>Users</p>
                </div>
                <div class="icon">
                  <i class="ion ion-person-add"></i>
                </div>
                <a href="view-subcategory.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div><?php */?><!-- ./col -->
            <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3><?php echo $nS4;?></h3>
                  <p>Products</p>
                </div>
                <div class="icon">
                  <i class="ion ion-bag"></i>
                </div>
                <a href="view-product.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            </div>
<div class="col-lg-3 col-xs-6">
              <!-- small box -->
                <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $nSfull;?></h3>
                  <p>Orders</p>
                </div>
                <div class="icon">
                  <i class="ion ion-ios-cart"></i>
                </div>
                <a href="booked-order.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div>
            <!--   <div class="small-box bg-green">
                <div class="inner">
                  <h3><?php echo $nS;?></h3>
                  <p>Orders</p>
                </div>
                <div class="icon">
                  <i class="ion ion-ios-cart"></i>
                </div>
                <a href="booked-order.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
              </div> -->
            </div>
    
          </div><!-- /.row -->

          <!-- /.row -->

          <!-- Main row -->
          <div class="row">
            <!-- Left col -->
            <div class="col-md-1"></div>
            <div class="col-md-10">
              <!-- MAP & BOX PANE -->
              <!-- /.box -->
                <div class="table-respopnsive table_body">
                    <h4><i class="fa fa-shopping-cart" aria-hidden="true"></i> Lastest Orders</h4>
                    <hr>
                 <table class="table table-striped table-hover">
                    <thead>
                      <tr class="bg_dark_tb">
                        <th>Order ID</th>
                        <th>Customer</th>
                        <th>Status</th>
                        <th>Total</th>
                      </tr>
                    </thead>
                    <tbody>
                 <?php while($orders=mysqli_fetch_assoc($sqlFol1)){?>
                      <tr>
                        <td><?php echo $orders['booked_id']; ?></td>
                        <td><?php echo $orders['userfname'];?></td>
                        <td><?php if($orders['shipping_status']== 0){echo 'Pending';}elseif($orders['shipping_status']== 1){echo 'Processing';}elseif($orders['shipping_status']== 2){echo 'Completed';}else{echo 'Cancelled';}?></td>
                        <td><?php echo $orders['total'];?></td>
                      </tr>
                   <?php } ?> 
                    </tbody>
                  </table>
                  </div>

              <!-- TABLE: LATEST ORDERS -->
              

              </div>
                <!-- /.col -->
            <!-- Left col -->
            <!--<div class="col-md-6">-->
              <!-- MAP & BOX PANE -->
              <!-- /.box -->
                <!--<div class="table-respopnsive table_body">-->
                <!--    <h4><i class="fa fa-comments-o" aria-hidden="true"></i> Lastest Reviews</h4>-->
                <!--    <hr>-->
                <!-- <table class="table table-striped table-hover">-->
                <!--    <thead>-->
                <!--      <tr class="bg_dark_tb">-->
                <!--        <th>Products</th>-->
                <!--        <th>Products</th>-->
                <!--        <th>Ratting</th>-->
                <!--      </tr>-->
                <!--    </thead>-->
                <!--    <tbody>-->
                <!--      <tr>-->
                <!--        <td>Redmi Note 7S (Sapphire Blue, 64 GB)  (4 GB RAM)</td>-->
                <!--        <td>deepak</td>-->
                <!--        <td>5/5</td>-->
                <!--      </tr>-->
                <!--      <tr>-->
                <!--        <td>Redmi Note 7S (Sapphire Blue, 64 GB)  (4 GB RAM)</td>-->
                <!--        <td>deepak</td>-->
                <!--        <td>5/5</td>-->
                <!--      </tr>-->
                <!--      <tr>-->
                <!--        <td>Redmi Note 7S (Sapphire Blue, 64 GB)  (4 GB RAM)</td>-->
                <!--        <td>deepak</td>-->
                <!--        <td>5/5</td>-->
                <!--      </tr>-->
                <!--    </tbody>-->
                <!--  </table>-->
                <!--  </div>-->

              <!-- TABLE: LATEST ORDERS -->
              

              </div>
                <!-- /.col -->


              </div><!-- /.row -->

              <!--<div class="box box-info">
                <div class="box-header">
                  <i class="fa fa-envelope"></i>
                  <h3 class="box-title">Quick Email</h3>

                  <div class="pull-right box-tools">

                  </div>
                </div>
                <form action="" method="post">
                <div class="box-body">

                    <div class="form-group">
                      <input type="email" class="form-control" name="emailto" placeholder="Email to:" required="required">
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" name="subject" placeholder="Subject" required="required">
                    </div>
                    <div>
                      <textarea class="textarea" name="msg" placeholder="Message" style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" required="required"></textarea>
                    </div>

                </div>
                <div class="box-footer clearfix">
                  <button type="submit" class="pull-right btn btn-success" name="sendEmail">Send <i class="fa fa-arrow-circle-right"></i></button>
                </div>
                  </form>
              </div>-->
            </div>


          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
        <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>

<?php
include('footer.php');
?>
