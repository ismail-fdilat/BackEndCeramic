<?php
include('config.php');

if(!isset($_SESSION['seller_id']))
{
	echo '<script>window.location.href="index.php"</script>';
}
$full_name = $_SERVER['PHP_SELF'];
       $name_array = explode('/',$full_name);
        $count = count($name_array);
      $page_name = $name_array[$count-1];

if(isset($_SESSION['seller_id']))
{
    $_SESSION['seller_id'];
	$connupdate=mysqli_query($conn,"update seller set loginstatus=1 where seller_id='".$_SESSION['seller_id']."'");
	$sqluser=mysqli_query($conn,"select * from seller where seller_id='".$_SESSION['seller_id']."'");
    $rowuser=mysqli_fetch_assoc($sqluser);
}
$logoget=mysqli_query($conn,"select * from logo ");
$logo=mysqli_fetch_assoc($logoget);


?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
        <title>Marble Ecommerce</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.5 -->
<link href="../img/logo.jpg" rel="icon" type="image/x-icon" />
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
    
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>    
  
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesnt work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
   <style>
   
.pagination>.active>a, .pagination>.active>a:focus, .pagination>.active>a:hover, .pagination>.active>span, .pagination>.active>span:focus, .pagination>.active>span:hover
{

z-index: 2;
    color: #fff;
    cursor: default;
    background-color: #80b500!important;
    border-color: #80b500 !important;


}   

.sidebar-menu {
    list-style: none;
    background: #000!important;
    margin: 0;
    padding: 0;
}
.skin-blue .main-header .navbar {
    background-color:#AF8D3C;
}
.skin-blue .wrapper, .skin-blue .main-sidebar, .skin-blue .left-side {
    background-color: #000;
}
</style> 
    
    
  </head>

	  <body class="hold-transition skin-blue sidebar-mini">


    <div class="wrapper">

      <header class="main-header">
        <!-- Logo -->
       <a href="" class="logo" style="
    background-color: #fff!important;
">
          <!-- mini logo for sidebar mini 50x50 pixels -->



	 <span class="logo-mini"><img src="upload/<?php echo $logo['image'];?>"style="width: 50px;" ><!--<img src="upload/<?php //echo  $logo['image'];?>"style="width: 50px;" >--></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><img src="upload/<?php echo $logo['image'];?>"style="width: 120px; height:45px;" ></span>




        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- <li class="dropdown notifications-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <i class="fa fa-bell-o"></i>
                  <span class="label label-warning">10</span>
                </a>
                <ul class="dropdown-menu">
                  <li class="header">You have 10 notifications</li>
                  <li> -->
                    <!-- inner menu: contains the actual data -->
                  <!--   <ul class="menu">
                      <li>
                        <a href="#">
                          <i class="fa fa-users text-aqua"></i> 5 new members joined today
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the page and may cause design problems
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i class="fa fa-users text-red"></i> 5 new members joined
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i class="fa fa-user text-red"></i> You changed your username
                        </a>
                      </li>
                    </ul> -->
               <!--    </li>
                  <li class="footer"><a href="#">View all</a></li>
                </ul>
              </li> -->

              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                 
					  <?php if($rowuser['simg'] !='')
				  {
					  ?>
                    <img src="upload/seller/<?php echo $rowuser['simg']?>" class="img-circle" alt="User Image" style="height:25px; width:25px">
					<?php
				  }
				  else
				  {
					  ?>
					  <img src="dist/img/user.png" class="img-circle" alt="User Image" style="height:25px; width:25px">
					  <?php
				  }
				  ?>
					
                  <span class="hidden-xs"><?php echo $rowuser['sname']?> </span>
                </a>
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
				  <?php if($rowuser['simg'] !='')
				  {
					  ?>
                    <img src="upload/seller/<?php echo $rowuser['simg']?>" class="img-circle" alt="User Image" style="height:90px; width:90px">
					<?php
				  }
				  else
				  {
					  ?>
					  <img src="dist/img/user.png" class="img-circle" alt="User Image" style="height:90px; width:90px">
					  <?php
				  }
				  ?>
                    <p>
                      <?php echo $rowuser['sname']?> 

                    </p>
                  </li>
                  <!-- Menu Body -->

                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-left">
                      <a href="profile.php" class="btn btn-default btn-flat">Profile</a>
                    </div>
                    <div class="pull-right">
                      <a href="logout.php" class="btn btn-default btn-flat">Sign out</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->

            </ul>
          </div>
        </nav>
      </header>
