 <?php
include('header.php');
include('nav.php');


	$sqlFol1=mysqli_query($conn,"select * from book_order where confirm_status=1 and shipping_status=3 order by id desc");
	$nS=mysqli_num_rows($sqlFol1);



if(isset($_GET['delid']))
{
	$sqlD=mysqli_query($conn, "delete from book_order  where id='".$_GET['delid']."' ");
	
	
	if($sqlD)
	{
		
		echo '<script>window.location.href="booked-order.php?sucmsg=Order Deleted Successfully"</script>';
	}
	else
	{
		$errmsg="Product Not Deleted ! Try Again";
	}
}

?>
 
<style>
.btn-change{
    background-color: #605ca8;
    border-color: #605ca8;
    color:white;
}
.btn-change:hover {
   background-color: #605ca8;
    border-color: #605ca8;
    color:white;
}
.label-pending
{
background-color: #f39c12;
}
</style>
<div class="content-wrapper">
        <!-- Content Header (Page header) -->
        

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->

              <div class="box">
                <div class="box-header">
                  <h3 class="">Cancelled Orders (<?php echo $nS;  ?>)</h3>
               
                  <?php
				     
                  if(isset($_GET['sucmsg']))
				  {
				  ?>
                  <center><h3 class="box-title" style="color:green;"><i class="fa fa-check"></i> <?php echo $_GET['sucmsg'];  ?> </h3></center>
                  <?php
				  }
				  if(isset($errmsg))
				  {
					  ?>
                      <center><h3 class="box-title" style="color:red"><i class="fa fa-times"></i> <?php echo $errmsg;  ?> </h3></center>
                      <?php
				  }
				  ?>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                  <table id="example1" class="table table-bordered table-striped" style="text-align:center">
                    <thead>
                      <tr style="font-weight:bold">
                                               		<td style="width: 46px;">#</td>
                         			 	<td>Order ID</td>
							<td>User</td>
							 <td>Amount</td>
                      				       <td>Payment Status</td>
                      				       
                      				       
							<td>Order Status</td>
                         				<td>Date</td>
                         				
						 	<td>Action</td>
                        </tr>
                    </thead>
                    <tbody>
                   <?php 
                   $i=1;
                   while($rowOrder=mysqli_fetch_assoc($sqlFol1))
					  {
						  
						  
						  
					
						  ?>
                        <tr>
                        <td><span  ><?php echo $i;?> </span></td>
        <td><a href="single-order.php?orderid=<?php echo $rowOrder['booked_id']?>"> <?php echo $rowOrder['booked_id']?></a></td>
                          
	<td><span >Name:- <?php echo $rowOrder['userfname']?> <?php echo $rowOrder['userlname']?></span><br/>	
		
	<span>Phone-<?php echo $rowOrder['userphone']?> </span><br/>
	<span>Email-<?php echo $rowOrder['useremail']?> </span></td>
	<td><span  >AED <?php echo $rowOrder['total']?> </span></td>
	  <td><?php if($rowOrder['payment_status']=='1')
	{
	?>
	<span class="label label-success" >Paid</span>
	<?php
	}else
	{
	?>
		<span class="label label-danger" >Pending</span>

	<?php
	}
	?>
	 </td>
	<td id="update_result<?php echo $rowOrder['id']?>">
	<?php if($rowOrder['shipping_status']=='0')
	{
	?>
	<span class="label label-pending" >Pending</span>
	<?php
	}elseif($rowOrder['shipping_status']=='1')
	{
	?>
		<span class="label label-info" >Processing</span>

	<?php
	}
	
	elseif($rowOrder['shipping_status']=='2')
	{
	?>
		<span class="label label-success" >Complete</span>

	<?php
	}
	elseif($rowOrder['shipping_status']=='3')
	{
	?>
		<span class="label label-danger" >Cancelled</span>

	<?php
	}
	?>
	 </td>
	<td><?php echo date('d M Y h:i A',strtotime($rowOrder['date']))?></td>	
		
		



        <td>
	   <a class="btn btn-success btn-sm" href="single-order.php?orderid=<?php echo $rowOrder['booked_id']?>" ><i class="fa fa-eye"></i> View </a>
        
</td>
                        </tr>
                        <?php
					$i++;	
					  }
					  ?>
                    </tbody>
                    <tfoot>
                    <tr style="font-weight:bold">
                         				<td>#</td>
                         			 	<td>Order ID</td>
							<td>User</td>
                      				        <td>Amount</td>
                      				          <td>Payment Status</td>
                      				        
							<td>Order Status</td>
                         				<td>Date</td>
						 	<td>Action</td>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
  <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="plugins/datatables/dataTables.bootstrap.min.js"></script> 
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>   
<?php
include('footer.php');
?>